import os 
from sklearn.preprocessing import LabelBinarizer
import torchaudio
import torch
import numpy as np
from PIL import Image
from torchvision import transforms
from torch.utils.data import Dataset,DataLoader
from sklearn.model_selection import train_test_split
import time
import logging
import configparser
from pathlib import Path
from datetime import datetime
from sklearn.metrics import accuracy_score, recall_score, confusion_matrix  
import matplotlib.pyplot as plt
import seaborn as sns
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import transforms
from torch.utils.data import DataLoader
from tqdm import tqdm
from NAAViGmodel import*

torch.cuda.empty_cache()  
data_dir=r"C:\Users\Desktop\dev-other-mel_spectrograms"
max_files_per_class=None
X = []
y = []
labels = sorted(os.listdir(data_dir))
label_binarizer = LabelBinarizer()
label_binarizer.fit(labels)
pretrained_means = [0.485, 0.456, 0.406]
pretrained_stds = [0.229, 0.224, 0.225]
transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
    ])

for label in labels:
    label_dir = os.path.join(data_dir, label)
    files = [os.path.join(root, file)
             for root, _, file_list in os.walk(label_dir)
             for file in file_list
             if file.endswith('.wav') or file.endswith('.png')]

    for file in files[:]:
            img=Image.open(file)
            img_tensor = transform(img.convert("RGB"))
            X.append(img_tensor)
            y.append(label)

y = label_binarizer.transform(y)
y=np.array(y)

class Dataset(Dataset):
    def __init__(self, X, y):
        self.X = X
        self.y = y

    def __len__(self):
        return len(self.X)
    
    def __getitem__(self, idx):
            audio_data = self.X[idx]
            label = self.y[idx]
            return torch.tensor(audio_data, dtype=torch.float32), torch.tensor(label, dtype=torch.float32)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=81, stratify=y)
train_dataset = Dataset(X_train, y_train)
test_dataset = Dataset(X_test, y_test)
train_batch_size = 256
test_batch_size = 64
num_class=y.shape[1]
train_loader = DataLoader(train_dataset, batch_size=train_batch_size, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=test_batch_size, shuffle=False)

def train_step(NAAViGmodel, dataloader, optimizer, criterion, device, epoch=None, mix_aug=None):
    running_loss, correct, total = [], 0, 0
    NAAViGmodel.train()

    train_bar = tqdm(dataloader)
    for x, y in train_bar:
        x, y = x.to(device), y.to(device).long()

        if mix_aug is not None:
            x, y = mix_aug(x, y)

        optimizer.zero_grad()

        _, pred = NAAViGmodel(x)
    
        loss = criterion(pred.float(), y.float())
        loss.backward()
        optimizer.step()

        pred = pred.argmax(dim=1, keepdim=False)
        y=y.argmax(dim=1, keepdim=False)
        total += y.size(0)
        correct += (pred == y).sum().item()
        
        running_loss.append(loss.item())
        train_bar.set_description(
            f'Epoch: [{epoch}] Loss: {round(sum(running_loss) / len(running_loss), 6)}')
    acc = correct / total
    return sum(running_loss) / len(running_loss), acc

def validation_step(NAAViGmodel, dataloader, device):  
    all_preds = []
    all_labels = []
    NAAViGmodel.eval()

    validation_bar = tqdm(dataloader)
    with torch.no_grad():
        for x, y in validation_bar:
            x, y = x.to(device), y.to(device)

            _, pred = NAAViGmodel(x)

            pred = pred.argmax(dim=1, keepdim=False)
            y = y.argmax(dim=1, keepdim=False)  
            all_preds.extend(pred.cpu().numpy())
            all_labels.extend(y.cpu().numpy())
    return all_preds, all_labels

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
conf = configparser.ConfigParser()
conf.read('confs/main.ini')

save_dir = Path(conf['TRAIN']['SAVE_DIR']) / \
    datetime.now().strftime('%Y%m%d_%H%M')
save_dir.mkdir(parents=True, exist_ok=True)
logging.basicConfig(level=logging.INFO, handlers=[
    logging.FileHandler(save_dir / 'train.log'),
    logging.StreamHandler()
])

NAAViGmodel = Classifier(n_classes=num_class,
                   num_ViGBlocks=conf['MODEL'].getint('DEPTH'),
                   out_feature=conf['MODEL'].getint('DIMENSION'),
                   num_edges=conf['MODEL'].getint('NUM_EDGES'),
                   head_num=conf['MODEL'].getint('HEAD_NUM'))
NAAViGmodel.to(device)
logging.info('NAA-ViG model loaded')
logging.info({section: dict(conf[section]) for section in conf.sections()})

criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(NAAViGmodel.parameters(), lr=conf['TRAIN'].getfloat('LR'))

loss_history, train_acc_hist, val_acc_hist, val_recall_hist = [], [], [], []  
max_val_acc = 0

since = time.time()
for epoch in range(1, conf['TRAIN'].getint('EPOCHS')+1):

    loss, train_acc = train_step(
        NAAViGmodel, train_loader, optimizer, criterion, device, epoch)
    val_preds, val_labels = validation_step(NAAViGmodel, test_loader, device)  
    val_acc = accuracy_score(val_labels, val_preds)
    val_recall = recall_score(val_labels, val_preds, average='macro')  
    
    loss_history.append(loss)
    train_acc_hist.append(train_acc)
    val_acc_hist.append(val_acc)
    val_recall_hist.append(val_recall)  
    
    logging.info(f'Epoch: {epoch}, Loss: {loss}, Train acc:{train_acc*100:.2f}%, Val acc: {val_acc*100:.2f}%, Val recall: {val_recall*100:.2f}%')

    if val_acc > max_val_acc:
        max_val_acc = val_acc
        torch.save(NAAViGmodel.state_dict(), save_dir / f'best_ViGmodel.pth')

logging.info('Training Finished.')
logging.info(f'Max validation accuracy: {max_val_acc*100:.2f}%')
logging.info(f'Max validation recall: {max(val_recall_hist)*100:.2f}%')
logging.info(f'Elapsed time: {time.time() - since:.2f}s')

NAAViGmodel.load_state_dict(torch.load(save_dir / 'best_ViGmodel.pth'))
