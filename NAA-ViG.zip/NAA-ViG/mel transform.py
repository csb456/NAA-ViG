import os
import torch
import torchaudio
import torchaudio.transforms as T
import matplotlib.pyplot as plt
import gc


plt.switch_backend('Agg')

dataset_dir = r"C:\Users\Desktop"
sample_rate = 16000

# Create a function to save the Mel spectrum graph.
def save_mel_spectrogram(audio, sr, file_path, save_base_dir):
    try:
        # Convert audio data to Mel spectrum
        mel_spectrogram = T.MelSpectrogram(
            sample_rate=sr,
            n_fft=2048,
            hop_length=512,
            n_mels=32,
            f_min=0,            
            f_max=8000,         
            power=2             
        )
        mel_spec = mel_spectrogram(audio)
       
        mel_spec_db = T.AmplitudeToDB()(mel_spec)

      
        rel_path = os.path.relpath(file_path, dataset_dir)
     
        dir_name, file_name = os.path.split(rel_path)
        
      
        save_path = os.path.join(save_base_dir, dir_name, file_name.replace('.wav', '.png').replace('.flac', '.png'))

      
        os.makedirs(os.path.dirname(save_path), exist_ok=True)

        
        plt.figure(figsize=(5, 2), dpi=100)  
        plt.imshow(mel_spec_db.squeeze().numpy(), aspect='auto', origin='lower', cmap="viridis")
        plt.axis('off')
        plt.savefig(save_path, bbox_inches='tight', pad_inches=0)
        plt.close()  
        
        
        gc.collect()
        
        return True
    except Exception as e:
        print(f"Error processing {file_path}: {str(e)}")
        plt.close('all') 
        gc.collect()
        return False


processed_count = 0
error_count = 0

for label in os.listdir(dataset_dir):
    label_dir = os.path.join(dataset_dir, label)
    if not os.path.isdir(label_dir):
        continue

 
    for root, _, file_list in os.walk(label_dir):
        for file in file_list:
            if file.endswith('.wav') or file.endswith('.flac'):
                file_path = os.path.join(root, file)
                try:
                  
                    audio, sr = torchaudio.load(file_path)

                    if sr != sample_rate:
                        audio = torchaudio.functional.resample(audio, sr, sample_rate)
                    
             
                    success = save_mel_spectrogram(audio, sample_rate, file_path, 'train360-mel')
                    
                    if success:
                        processed_count += 1
                    else:
                        error_count += 1
                    
                  
                    if processed_count % 100 == 0:
                        print(f"Processed {processed_count} files, {error_count} errors")
                        gc.collect()  
                
                except Exception as e:
                    print(f"Error loading {file_path}: {str(e)}")
                    error_count += 1
                    plt.close('all') 
                    gc.collect()

print(f"Processing complete! Total files: {processed_count + error_count}, Processed: {processed_count}, Errors: {error_count}")
    